package com.example.myapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import kotlin.math.log

class MainActivity : AppCompatActivity() {

    lateinit var textView: TextView;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textView =findViewById(R.id.TextView)

    }
    fun pressButtonAction(view: View){
        val textViewText = textView.text.toString()
        val display = view as Button
        val Helloworld = display.text.toString()
        textView.text = "Hello world !"
        Log.d("MainActivity",textViewText)

    }
}